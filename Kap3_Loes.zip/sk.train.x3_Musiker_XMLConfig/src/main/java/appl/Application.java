package appl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import ifaces.Performer;

public class Application {
	public static void main(String[] args) {
		try (final ClassPathXmlApplicationContext ctx = 
				new ClassPathXmlApplicationContext("spring.xml")) {
			
			
			Performer klavierspieler = (Performer) ctx.getBean("klavierspieler");
			Performer gitarist = (Performer) ctx.getBean("gitarist");
			
			klavierspieler.perform();
			gitarist.perform();
			
			
			
			
			


			
		}
	}
}

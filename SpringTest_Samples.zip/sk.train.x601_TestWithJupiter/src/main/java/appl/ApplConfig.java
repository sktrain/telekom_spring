package appl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import beans.DiffServiceImpl;
import beans.MathServiceImpl;
import beans.SumServiceImpl;
import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;
import jn.util.Log;

@Configuration
public class ApplConfig {
	
	public ApplConfig() {
		Log.log();
	}
	
	
	//<bean id="sumService" class="beans.SumServiceImpl"/>
	@Bean(name="sum")
	public SumService sumService() {
		Log.log();
		return new SumServiceImpl();
	}
	
	@Bean
	public SumService sumService2() {
		Log.log();
		return new SumServiceImpl();
	}
	@Bean
	public DiffService diffService() {
		Log.log();
		return new DiffServiceImpl();
	}
	
//	<bean id="mathService" class="beans.MathServiceImpl"> 
//	<constructor-arg ref="sumService"/>
//	<constructor-arg ref="diffService"/>
//</bean>
	@Bean
	public MathService mathService() {
		Log.log();
		return new MathServiceImpl(this.sumService2(), this.diffService());
	}
}

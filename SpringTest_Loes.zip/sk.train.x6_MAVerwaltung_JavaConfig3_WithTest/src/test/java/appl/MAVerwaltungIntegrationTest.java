package appl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.Comparator;

import javax.swing.table.TableModel;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import sk.train.ma.strategy.verwaltung.MitarbeiterVerwaltungIf;

@SpringJUnitConfig (ApplConfig.class )
class MAVerwaltungIntegrationTest {
	
	
	@Test
	void contextLoads() {
	}
	
	@Test
	public void TestTableModel(@Autowired ApplicationContext ctx) {
		TableModel model = ctx.getBean("tablemodel", TableModel.class);
		MitarbeiterVerwaltungIf mv = ctx.getBean(MitarbeiterVerwaltungIf.class);
		assertEquals(model.getRowCount(), mv.getMlist(Comparator.naturalOrder()).size());
		//...
	}
	


}


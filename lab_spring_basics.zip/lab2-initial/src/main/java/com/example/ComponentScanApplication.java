package com.example;

public class ComponentScanApplication {

    public static void main(String[] args) {

    }

}

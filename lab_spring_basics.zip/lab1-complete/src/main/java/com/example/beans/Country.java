package com.example.beans;

public enum Country {
    GERMANY,
    AUSTRIA,
    SWITZERLAND
}

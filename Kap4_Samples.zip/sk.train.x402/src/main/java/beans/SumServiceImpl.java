package beans;

import org.springframework.stereotype.Component;

import ifaces.SumService;
import jn.util.Log;

//@Component
public class SumServiceImpl implements SumService {
	public SumServiceImpl() { 
		Log.log();
	}
	@Override
	public int sum(int x, int y) {
		return x + y;
	}
}

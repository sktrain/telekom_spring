package beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;
import jn.util.Log;

@Component
// @Component("Math")
public class MathServiceImpl implements MathService {
	
	@Autowired   // REQUIRED!
	private SumService schall;

	@Autowired   // REQUIRED!
	private DiffService rauch;
	
	public MathServiceImpl() {
		Log.log();
	}
	
	@Override
	public int sum(int x, int y) {
		return this.schall.sum(x, y);
	}

	@Override
	public int diff(int x, int y) {
		return this.rauch.diff(x, y);
	}
}

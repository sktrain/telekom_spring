package beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;
import jn.util.Log;

//@Component
@Component("Math")
public class MathServiceImpl implements MathService {
	
	private final SumService sumService;
	private final DiffService diffService;

//	public MathServiceImpl() {
//		this(null, null);
//	}

	@Autowired  // nur notwendig, wenn noch ein anderer Konstruktor existiert...
	public MathServiceImpl(SumService sumService, DiffService diffService) {
		Log.log(sumService, diffService);
		this.sumService = sumService;
		this.diffService = diffService;
	}
	
	@Override
	public int sum(int x, int y) {
		return this.sumService.sum(x, y);
	}

	@Override
	public int diff(int x, int y) {
		return this.diffService.diff(x, y);
	}
}

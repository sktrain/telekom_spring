package beans;

import org.springframework.stereotype.Service;

import ifaces.SumService;
import jn.util.Log;

@Service
//@Component
public class SumServiceImpl implements SumService {
	public SumServiceImpl() { 
		Log.log();
	}
	@Override
	public int sum(int x, int y) {
		return x + y;
	}
}

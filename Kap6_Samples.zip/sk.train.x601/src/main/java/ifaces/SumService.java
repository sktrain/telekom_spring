package ifaces;

public interface SumService {
	public abstract int sum(int x, int y);
}

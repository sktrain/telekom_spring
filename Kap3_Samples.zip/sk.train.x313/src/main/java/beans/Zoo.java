package beans;

import java.util.List;
import java.util.Set;

import jn.util.Log;

public class Zoo {
	
	private List<String> list;
	private Set<String> set;
	private String[] array;
	private List<Language> languageList;

	public void setList(List<String> list) {
		Log.log(list);
		this.list = list;
	}
	public void setSet(Set<String> set) {
		Log.log(set);
		this.set = set;
	}
	public void setArray(String[] array) {
		Log.log((Object[])array);
		this.array = array;
	}
	public void setLanguageList(List<Language> languageList) {
		Log.log(languageList);
		this.languageList = languageList;
	}
	public void print() {
		//System.out.println(this.list.getClass());
		System.out.println(this.list.getClass());
		for (String s : this.list)
			System.out.println(s);
		System.out.println();
		System.out.println(this.set.getClass());
		for (String s : this.set)
			System.out.println(s);
		System.out.println();
		for (String s : this.array)
			System.out.println(s);
		System.out.println();
		for (Language l : this.languageList) {
			System.out.println(l);
		}
	}

}

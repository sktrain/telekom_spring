package appl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import ifaces.DiffService;
import ifaces.SumService;

public class Application {
	public static void main(String[] args) {

		try (final ClassPathXmlApplicationContext parent = new ClassPathXmlApplicationContext("spring1.xml")) {
			try (final ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext()) {
				ctx.setParent(parent);
				ctx.setConfigLocations("spring2.xml");
				ctx.refresh();

				final SumService sumService = ctx.getBean(SumService.class);
				System.out.println(sumService.sum(40, 2));
				final DiffService diffService = ctx.getBean(DiffService.class);
				System.out.println(diffService.diff(80, 3));
			}
		}
	}
}

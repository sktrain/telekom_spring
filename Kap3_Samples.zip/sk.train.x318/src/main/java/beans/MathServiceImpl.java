package beans;

import ifaces.MathService;
import jn.util.Log;

public class MathServiceImpl implements MathService {

	public MathServiceImpl() {
		Log.log();
	}
	public int sum(int x, int y) {
		return x + y;
	}
	public int diff(int x, int y) {
		return x - y;
	}
}

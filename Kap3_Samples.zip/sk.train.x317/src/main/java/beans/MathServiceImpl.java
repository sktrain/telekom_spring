package beans;

import ifaces.DiffService;
import ifaces.Listener;
import ifaces.MathService;
import ifaces.SumService;
import jn.util.Log;

public class MathServiceImpl implements MathService, Listener {

	private SumService sumService;
	private DiffService diffService;
	
	public void setSumService(SumService sumService) {
		Log.log(sumService);
		this.sumService = sumService;
	}
	public void setDiffService(DiffService diffService) {
		Log.log(diffService);
		this.diffService = diffService;
	}
	public int sum(int x, int y) {
		return this.sumService.sum(x, y);
	}
	public int diff(int x, int y) {
		return this.diffService.diff(x, y);
	}
	public void notify(String msg) {
		System.out.println("notify: " + msg);
	}
}

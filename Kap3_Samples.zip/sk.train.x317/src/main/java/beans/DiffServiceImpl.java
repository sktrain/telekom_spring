package beans;

import ifaces.DiffService;
import ifaces.Listener;
import jn.util.Log;

public class DiffServiceImpl implements DiffService {
	private Listener listener;
	public void setListener(Listener listener) {
		Log.log(listener);
		this.listener = listener;
	}
	public int diff(int x, int y) {
		if (this.listener != null)
			this.listener.notify("diff(" + x + ", " + y + ")");
		return x - y;
	}
}

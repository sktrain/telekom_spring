package beans;

import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;
import jn.util.Log;

public class MathServiceImpl implements MathService {
	
	private SumService sumService;
	private DiffService diffService;
	
	public MathServiceImpl() { 
		Log.log();
	}

	public void setSumService(SumService sumService) { // must(!) be public
		Log.log(sumService);
		this.sumService = sumService;
	}
	
	public void setDiffService(DiffService diffService) { // must(!) be public
		Log.log(diffService);
		this.diffService = diffService;
	}

	@Override
	public int sum(int x, int y) {
		return this.sumService.sum(x, y);
	}

	@Override
	public int diff(int x, int y) {
		return this.diffService.diff(x, y);
	}
}

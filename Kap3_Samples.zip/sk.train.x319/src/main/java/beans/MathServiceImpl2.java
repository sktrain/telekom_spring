package beans;

import ifaces.MathService;
import jn.util.Log;

public class MathServiceImpl2 implements MathService {
	
	public MathServiceImpl2() {
		Log.log();
	}
	
	@Override
	public int sum(int x, int y) {
		if (y == 0)
			return x;
		return 1 + sum(x, y - 1);
	}

	@Override
	public int diff(int x, int y) {
		if (y == 0)
			return x;
		return diff(x, y - 1) - 1;
	}
}

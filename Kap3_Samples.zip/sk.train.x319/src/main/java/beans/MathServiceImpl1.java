package beans;

import ifaces.MathService;
import jn.util.Log;

public class MathServiceImpl1 implements MathService {
	
	public MathServiceImpl1() {
		Log.log();
	}
	
	@Override
	public int sum(int x, int y) {
		return x + y;
	}

	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}

package sk.train.strategy.model;

public enum Geschlecht { W, M, D

}

package appl;

public class SumEvent extends MathEvent {

	private static final long serialVersionUID = 1L;

	public final int x;
	public final int y;
	
	public SumEvent(Object source, int x, int y) {
		super(source);
		this.x = x;
		this.y = y;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + " [" + this.x + ", " + this.y + "]";
	}
}

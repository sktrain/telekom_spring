package beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Service;

import ifaces.MathService;
import jn.util.Log;

@Service
public class MathServiceImpl implements MathService {
	
	@PostConstruct
	private void postConstruct() {
		Log.log();
	}
	
	@PreDestroy
	private void preDestroy() {
		Log.log();
	}
	
	@Override
	public int sum(int x, int y) {
		return x + y;
	}

	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}

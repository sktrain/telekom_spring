package appl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import beans.MathServiceImpl;
import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;
import jn.util.Log;

@Configuration
public class ApplConfig {

	private SumService sumService;
	private DiffService diffService;
	
	@Autowired
	public void setHelperServices(SumService sumService, DiffService diffService) {
		Log.log(sumService, diffService);
		this.sumService = sumService;
		this.diffService = diffService;
	}
	
	@Bean 
	public MathService mathService() {
		Log.log();
		return new MathServiceImpl(this.sumService, this.diffService);
	}
}

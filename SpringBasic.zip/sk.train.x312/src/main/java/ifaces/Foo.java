package ifaces;

import java.awt.Point;
import java.util.Date;

public interface Foo {
	public abstract String getS();
	public abstract int getI();
	public abstract double getD();
	public abstract Integer getIw();
	public abstract Double getDw();
	public abstract Date getDate();
	public abstract Point getPoint();
}

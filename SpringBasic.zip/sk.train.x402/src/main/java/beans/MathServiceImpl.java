package beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;
import jn.util.Log;

@Component
// @Component("Math")
public class MathServiceImpl implements MathService {
	
	private SumService sumService;
	private DiffService diffService;

	public MathServiceImpl() {
		Log.log();
	}

//	@Autowired
//	public void schall(SumService sumService) { 
//		Log.log();
//		this.sumService = sumService;
//	}
//	
//	@Autowired
//	public void rauch(DiffService diffService) {
//		Log.log();
//		this.diffService = diffService;
//	}

	@Autowired(required=false) // REQUIRED
	// @Inject // Alternative. Add to classpath: CDI-user-lib
	public void schallUndRauchh(SumService sumService) { 
		Log.log(sumService, diffService);
		this.sumService = sumService;
		
	}
	
	@Autowired // REQUIRED
	// @Inject // Alternative. Add to classpath: CDI-user-lib
	public void schallUndRauchh(DiffService diffService) { 
		Log.log(sumService, diffService);
		
		this.diffService = diffService;
	}

	@Override
	public int sum(int x, int y) {
		return this.sumService.sum(x, y);
	}

	@Override
	public int diff(int x, int y) {
		return this.diffService.diff(x, y);
	}
}

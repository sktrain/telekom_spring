package ifaces;

public interface DiffService {
	public abstract int diff(int x, int y);
}

package advices;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

import jn.util.JoinPointTrace;

@Aspect
public class TraceAdvice {
	
	@Around("execution(public void play())")
	public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
		JoinPointTrace.trace(">> ", joinPoint, null);
		final Object result = joinPoint.proceed();
		JoinPointTrace.trace("<< ", joinPoint, result);
		return result;
	}
}

package appl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import iface.MathService;

public class Application {
	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml")) {

			final MathService mathService = ctx.getBean(MathService.class);

			System.out.println(mathService.sum(40, 2));
			try {
				System.out.println(mathService.diff(-80, -3));
			}
			catch (final Exception e) {
				System.out.println(e);
			}

		}
	}
}

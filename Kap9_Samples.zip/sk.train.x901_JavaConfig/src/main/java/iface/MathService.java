package iface;

public interface MathService {
	public abstract int sum(int x, int y);
	public abstract int diff(int x, int y);
}
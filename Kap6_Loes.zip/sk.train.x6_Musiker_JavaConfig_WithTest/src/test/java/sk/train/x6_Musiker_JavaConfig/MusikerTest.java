package sk.train.x6_Musiker_JavaConfig;

import static org.junit.jupiter.api.Assertions.assertNotSame;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import appl.ApplConfig;
import ifaces.Performer;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = { ApplConfig.class })
class MusikerTest {
	
	
	@Test
	void contextLoads() {
	}
	
	@Autowired
	@Qualifier("klavierspieler")
	Performer klavierspieler1;
	@Autowired
	@Qualifier("klavierspieler")
	Performer klavierspieler2;
	
	
	@Autowired
	@Qualifier("gitarist")
	Performer gitarist1;
	@Autowired
	@Qualifier("gitarist")
	Performer gitarist2;
	
	@Test
	public void isPrototype() {
		assertNotSame(klavierspieler2, klavierspieler1);
		assertNotSame(gitarist2, gitarist1);
	}

}


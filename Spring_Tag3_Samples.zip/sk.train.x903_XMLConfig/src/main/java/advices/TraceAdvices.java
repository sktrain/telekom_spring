package advices;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

import jn.util.JoinPointTrace;

@Aspect
public class TraceAdvices {
	@Before("within(beans..*)")
	public void before(JoinPoint joinPoint) {
		JoinPointTrace.trace(">> ", joinPoint, null);
	}
	
	@AfterReturning(pointcut="within(beans..*)",returning="result")
	public void afterReturning(JoinPoint joinPoint, Object result) {
		JoinPointTrace.trace("<< ", joinPoint, result);
	}

	@AfterThrowing(pointcut="within(beans..*)",throwing="exception")
	public void afterThrowing(JoinPoint joinPoint, Object exception) {
		JoinPointTrace.trace("<< ", joinPoint, exception);
	}
}

package appl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import advices.TraceAdvices;
import beans.MathServiceImpl;
import iface.MathService;
import jn.util.Log;


@Configuration
@EnableAspectJAutoProxy
public class ApplConfig {
	
	public ApplConfig() {
		Log.log();
	}
	
	
	@Bean
	public MathService mathService() {
		Log.log();
		return new MathServiceImpl();
	}
	
	@Bean
	public TraceAdvices traceAdvices() {
		Log.log();
		return new TraceAdvices();
	}
}

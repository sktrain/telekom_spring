package advices;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

import jn.util.JoinPointTrace;

@Aspect
public class TraceAdvices {
	//@Around("execution(public * *(..))")
	//@Around("execution(public * sum(..))")
	@Around("execution(public int sum(int,int))")
	public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
		JoinPointTrace.trace(">> ", joinPoint, null);
		final Object result = joinPoint.proceed();
		JoinPointTrace.trace("<< ", joinPoint, result);
		return result;
	}
}
